<?php
/**
 * Plugin Name: Fast Quote Form
 * Description: A beautiful, modern "Get a Fast Quote" form with database storage and email notifications.
 * Version: 1.1.0
 * Author: James
 */

if (!defined('ABSPATH')) {
    exit;
}

define('FQF_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FQF_PLUGIN_URL', plugin_dir_url(__FILE__));
define('FQF_VERSION', '1.1.1');

// Includes
require_once FQF_PLUGIN_DIR . 'includes/db-manager.php';
require_once FQF_PLUGIN_DIR . 'includes/shortcode.php';
require_once FQF_PLUGIN_DIR . 'includes/form-handler.php';
require_once FQF_PLUGIN_DIR . 'includes/admin-forms.php';
require_once FQF_PLUGIN_DIR . 'includes/admin-settings.php';
require_once FQF_PLUGIN_DIR . 'includes/admin-entries.php';

// Activation & Init
register_activation_hook(__FILE__, ['FQF_DB_Manager', 'create_table']);
add_action('admin_init', ['FQF_DB_Manager', 'create_table']); // Ensure tables exist on admin load

// Admin Menu
add_action('admin_menu', 'fqf_add_admin_menu');
function fqf_add_admin_menu()
{
    add_menu_page(
        'Fast Quotes',
        'Fast Quotes',
        'manage_options',
        'fast-quote-forms',
        'fqf_render_forms_page',
        'dashicons-list-view',
        25
    );

    add_submenu_page(
        'fast-quote-forms',
        'All Forms',
        'All Forms',
        'manage_options',
        'fast-quote-forms',
        'fqf_render_forms_page'
    );

    add_submenu_page(
        'fast-quote-forms',
        'Add New',
        'Add New',
        'manage_options',
        'fast-quote-settings',
        'fqf_render_settings_page'
    );

    add_submenu_page(
        'fast-quote-forms',
        'Entries',
        'Entries',
        'manage_options',
        'fast-quote-entries',
        'fqf_render_entries_page'
    );
}

// Enqueue scripts and styles
add_action('wp_enqueue_scripts', 'fqf_enqueue_assets');
function fqf_enqueue_assets()
{
    wp_enqueue_style('fqf-style', FQF_PLUGIN_URL . 'assets/css/style.css', [], filemtime(FQF_PLUGIN_DIR . 'assets/css/style.css'));
    wp_enqueue_script('fqf-handler', FQF_PLUGIN_URL . 'assets/js/form-handler.js', ['jquery'], filemtime(FQF_PLUGIN_DIR . 'assets/js/form-handler.js'), true);

    wp_localize_script('fqf-handler', 'fqf_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('fqf_quote_nonce')
    ]);
}

// Admin Assets
add_action('admin_enqueue_scripts', 'fqf_enqueue_admin_assets');
function fqf_enqueue_admin_assets($hook)
{
    if (strpos($hook, 'fast-quote') !== false) {
        wp_enqueue_media();
        wp_enqueue_script('jquery-ui-sortable');
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }
}
