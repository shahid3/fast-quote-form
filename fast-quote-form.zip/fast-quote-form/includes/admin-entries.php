<?php
if (!defined('ABSPATH')) {
    exit;
}

function fqf_render_entries_page()
{
    global $wpdb;
    $entries_table = $wpdb->prefix . 'fast_quotes';
    $forms_table = $wpdb->prefix . 'fqf_forms';

    // Handle Bulk Actions
    if (isset($_POST['bulk_action']) && $_POST['bulk_action'] !== '-1' && isset($_POST['entry_ids'])) {
        check_admin_referer('fqf_bulk_action');
        $ids = array_map('intval', $_POST['entry_ids']);
        $action = $_POST['bulk_action'];

        if ($action === 'trash') {
            $wpdb->query("UPDATE $entries_table SET status = 'trashed' WHERE id IN (" . implode(',', $ids) . ")");
            echo '<div class="updated"><p>' . count($ids) . ' entries moved to bin.</p></div>';
        } elseif ($action === 'restore') {
            $wpdb->query("UPDATE $entries_table SET status = 'active' WHERE id IN (" . implode(',', $ids) . ")");
            echo '<div class="updated"><p>' . count($ids) . ' entries restored.</p></div>';
        } elseif ($action === 'delete') {
            $wpdb->query("DELETE FROM $entries_table WHERE id IN (" . implode(',', $ids) . ")");
            echo '<div class="updated"><p>' . count($ids) . ' entries permanently deleted.</p></div>';
        }
    }

    // Handle Single Actions
    if (isset($_GET['action']) && isset($_GET['entry_id'])) {
        check_admin_referer('fqf_entry_action');
        $id = intval($_GET['entry_id']);
        $action = $_GET['action'];

        if ($action === 'trash') {
            $wpdb->update($entries_table, ['status' => 'trashed'], ['id' => $id]);
            echo '<div class="updated"><p>Entry moved to bin.</p></div>';
        } elseif ($action === 'restore') {
            $wpdb->update($entries_table, ['status' => 'active'], ['id' => $id]);
            echo '<div class="updated"><p>Entry restored.</p></div>';
        } elseif ($action === 'delete') {
            $wpdb->delete($entries_table, ['id' => $id]);
            echo '<div class="updated"><p>Entry permanently deleted.</p></div>';
        }
    }

    $selected_form_id = isset($_GET['form_id']) ? intval($_GET['form_id']) : 0;
    $view = isset($_GET['view']) ? sanitize_text_field($_GET['view']) : 'active';
    $paged = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
    $per_page = 20;
    $offset = ($paged - 1) * $per_page;

    // Get all forms for filter dropdown
    $forms = FQF_DB_Manager::get_all_forms();

    // If no form selected, pick the latest one to show columns
    if ($selected_form_id === 0 && !empty($forms)) {
        $selected_form_id = $forms[0]->id;
    }

    $form = FQF_DB_Manager::get_form($selected_form_id);
    $headers = [];
    if ($form) {
        foreach ($form->fields as $field) {
            $headers[] = $field['label'];
        }
    }

    // Fetch entries
    $query = "SELECT * FROM $entries_table WHERE status = %s";
    $query_args = [$view];

    if ($selected_form_id > 0) {
        $query .= " AND form_id = %d";
        $query_args[] = $selected_form_id;
    }

    // Total for pagination
    $total_query = str_replace("SELECT *", "SELECT COUNT(*)", $query);
    $total_items = $wpdb->get_var($wpdb->prepare($total_query, ...$query_args));
    $total_pages = ceil($total_items / $per_page);

    $query .= " ORDER BY time DESC LIMIT %d OFFSET %d";
    $query_args[] = $per_page;
    $query_args[] = $offset;
    $entries = $wpdb->get_results($wpdb->prepare($query, ...$query_args));

    // Counts for subsubsub
    $active_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $entries_table WHERE status = 'active'"));
    $trashed_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $entries_table WHERE status = 'trashed'"));

    ?>
    <div class="wrap">
        <h1>Quote Form Entries</h1>

        <ul class="subsubsub">
            <li><a href="?page=fast-quote-entries&view=active"
                    class="<?php echo $view === 'active' ? 'current' : ''; ?>">All <span
                        class="count">(<?php echo $active_count; ?>)</span></a> |</li>
            <li><a href="?page=fast-quote-entries&view=trashed"
                    class="<?php echo $view === 'trashed' ? 'current' : ''; ?>">Bin <span
                        class="count">(<?php echo $trashed_count; ?>)</span></a></li>
        </ul>

        <form method="post" action="">
            <?php wp_nonce_field('fqf_bulk_action'); ?>
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <select name="bulk_action">
                        <option value="-1">Bulk actions</option>
                        <?php if ($view === 'active'): ?>
                            <option value="trash">Move to Bin</option>
                        <?php else: ?>
                            <option value="restore">Restore</option>
                            <option value="delete">Delete Permanently</option>
                        <?php endif; ?>
                    </select>
                    <input type="submit" class="button action" value="Apply">
                </div>

                <div class="alignleft actions">
                    <select
                        onchange="location.href='?page=fast-quote-entries&view=<?php echo $view; ?>&form_id=' + this.value">
                        <option value="0">All Forms</option>
                        <?php foreach ($forms as $f): ?>
                            <option value="<?php echo $f->id; ?>" <?php selected($selected_form_id, $f->id); ?>>
                                <?php echo esc_html($f->name); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <?php if ($total_pages > 1): ?>
                    <div class="tablenav-pages">
                        <span class="displaying-num"><?php echo $total_items; ?> items</span>
                        <?php
                        echo paginate_links([
                            'base' => add_query_arg('paged', '%#%'),
                            'format' => '',
                            'prev_text' => __('&laquo;'),
                            'next_text' => __('&raquo;'),
                            'total' => $total_pages,
                            'current' => $paged,
                        ]);
                        ?>
                    </div>
                <?php endif; ?>
            </div>

            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <td id="cb" class="manage-column column-cb check-column">
                            <input id="cb-select-all-1" type="checkbox">
                        </td>
                        <th style="width: 150px;">Date</th>
                        <?php if ($selected_form_id === 0): ?>
                            <th>Form Name</th>
                            <th>Data Summary</th>
                        <?php else: ?>
                            <?php foreach ($headers as $label): ?>
                                <th><?php echo esc_html($label); ?></th>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <th style="width: 100px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($entries): ?>
                        <?php foreach ($entries as $entry):
                            $data = json_decode($entry->data, true);
                            ?>
                            <tr>
                                <th scope="row" class="check-column">
                                    <input type="checkbox" name="entry_ids[]" value="<?php echo $entry->id; ?>">
                                </th>
                                <td><?php echo esc_html($entry->time); ?></td>
                                <?php if ($selected_form_id === 0):
                                    $f_name = $wpdb->get_var($wpdb->prepare("SELECT name FROM $forms_table WHERE id = %d", $entry->form_id));
                                    ?>
                                    <td><strong><?php echo esc_html($f_name); ?></strong></td>
                                    <td>
                                        <?php
                                        foreach ($data as $l => $v) {
                                            echo "<strong>$l:</strong> " . esc_html($v) . " | ";
                                        }
                                        ?>
                                    </td>
                                <?php else: ?>
                                    <?php foreach ($headers as $label): ?>
                                        <td><?php echo isset($data[$label]) ? esc_html($data[$label]) : '-'; ?></td>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                                <td>
                                    <?php
                                    $nonce = wp_create_nonce('fqf_entry_action');
                                    $base_url = "?page=fast-quote-entries&entry_id={$entry->id}&_wpnonce=$nonce&view=$view&form_id=$selected_form_id&paged=$paged";
                                    if ($view === 'active'): ?>
                                        <a href="<?php echo $base_url . '&action=trash'; ?>" style="color: #a00;">Trash</a>
                                    <?php else: ?>
                                        <a href="<?php echo $base_url . '&action=restore'; ?>">Restore</a> |
                                        <a href="<?php echo $base_url . '&action=delete'; ?>" style="color: #a00;"
                                            onclick="return confirm('Permanently delete this entry?')">Delete</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="<?php echo ($selected_form_id === 0) ? 5 : count($headers) + 3; ?>">No entries found.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </form>
    </div>
    <script>
        jQuery(document).ready(function ($) {
            $('#cb-select-all-1').click(function () {
                $('input[name="entry_ids[]"]').prop('checked', this.checked);
            });
        });
    </script>
    <?php
}
