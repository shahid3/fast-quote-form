<?php
if (!defined('ABSPATH')) {
    exit;
}

// Handle Form Saving before headers
add_action('admin_init', 'fqf_handle_form_save');
function fqf_handle_form_save()
{
    if (!isset($_POST['fqf_save_form'])) {
        return;
    }

    if (!current_user_can('manage_options')) {
        return;
    }

    check_admin_referer('fqf_form_nonce');

    global $wpdb;
    $table_name = $wpdb->prefix . 'fqf_forms';
    $form_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $is_new = ($form_id === 0);

    $form_name = sanitize_text_field($_POST['form_name']);
    $show_heading = isset($_POST['show_heading']) ? 1 : 0;
    $heading_text = sanitize_text_field($_POST['heading_text']);
    $email_subject = sanitize_text_field($_POST['email_subject']);
    $email_from = sanitize_text_field($_POST['email_from']);
    $primary_color = sanitize_hex_color($_POST['primary_color']);
    $notification_email = sanitize_email($_POST['notification_email']);
    $success_message = sanitize_textarea_field($_POST['success_message']);
    $redirect_url = esc_url_raw($_POST['redirect_url']);
    $instant_redirect = isset($_POST['instant_redirect']) ? 1 : 0;
    $email_from_address = sanitize_email($_POST['email_from_address']);
    $email_bcc = sanitize_text_field($_POST['email_bcc']); // Could be multiple comma-separated emails

    $submitted_fields = [];
    if (isset($_POST['fields']) && is_array($_POST['fields'])) {
        foreach ($_POST['fields'] as $field) {
            if (empty($field['label']))
                continue;
            $submitted_fields[] = [
                'label' => sanitize_text_field($field['label']),
                'type' => sanitize_text_field($field['type']),
                'icon_type' => sanitize_text_field($field['icon_type']),
                'icon_value' => ($field['icon_type'] === 'svg') ? $field['icon_value'] : sanitize_text_field($field['icon_value']),
                'required' => isset($field['required']) ? 1 : 0,
                'options' => sanitize_textarea_field($field['options']),
            ];
        }
    }

    $data = [
        'name' => $form_name,
        'fields' => json_encode($submitted_fields),
        'settings' => json_encode([
            'show_heading' => $show_heading,
            'heading_text' => $heading_text,
            'email_subject' => $email_subject,
            'email_from' => $email_from,
            'primary_color' => $primary_color,
            'notification_email' => $notification_email,
            'success_message' => $success_message,
            'redirect_url' => $redirect_url,
            'instant_redirect' => $instant_redirect,
            'email_from_address' => $email_from_address,
            'email_bcc' => $email_bcc
        ])
    ];

    if ($is_new) {
        $data['created_at'] = current_time('mysql');
        $result = $wpdb->insert($table_name, $data);
        if ($result !== false) {
            $form_id = $wpdb->insert_id;
            wp_redirect(admin_url('admin.php?page=fast-quote-settings&id=' . $form_id . '&updated=1'));
            exit;
        } else {
            wp_die('Database Error: Failed to create form. ' . $wpdb->last_error);
        }
    } else {
        $result = $wpdb->update($table_name, $data, ['id' => $form_id]);
        if ($result === false) {
            wp_die('Database Error: Failed to update form. ' . $wpdb->last_error);
        }
        wp_redirect(admin_url('admin.php?page=fast-quote-settings&id=' . $form_id . '&updated=2'));
        exit;
    }
}

function fqf_render_settings_page()
{
    if (!current_user_can('manage_options')) {
        return;
    }

    $form_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $is_new = ($form_id === 0);

    // Default values
    $show_heading = 1;
    $heading_text = 'Get a Fast Quote';
    $email_subject = 'New Quote Request';
    $email_from = get_bloginfo('name');
    $primary_color = '#6366F1';
    $notification_email = get_option('admin_email');
    $site_domain = parse_url(get_site_url(), PHP_URL_HOST);
    $email_from_address = 'admin@' . $site_domain;
    $email_bcc = '';
    $success_message = 'Your quote request has been sent successfully!';
    $redirect_url = '';
    $instant_redirect = 0;
    $fields = [
        ['label' => 'Name', 'type' => 'text', 'icon_type' => 'fa', 'icon_value' => 'fas fa-user', 'required' => 1, 'options' => ''],
        ['label' => 'Email', 'type' => 'email', 'icon_type' => 'fa', 'icon_value' => 'fas fa-envelope', 'required' => 1, 'options' => '']
    ];

    if (!$is_new) {
        $form = FQF_DB_Manager::get_form($form_id);
        if ($form) {
            $form_name = $form->name;
            $show_heading = isset($form->settings['show_heading']) ? $form->settings['show_heading'] : $show_heading;
            $heading_text = isset($form->settings['heading_text']) ? $form->settings['heading_text'] : $heading_text;
            $email_subject = isset($form->settings['email_subject']) ? $form->settings['email_subject'] : $email_subject;
            $email_from = isset($form->settings['email_from']) ? $form->settings['email_from'] : $email_from;
            $primary_color = isset($form->settings['primary_color']) ? $form->settings['primary_color'] : $primary_color;
            $notification_email = isset($form->settings['notification_email']) ? $form->settings['notification_email'] : $notification_email;
            $success_message = isset($form->settings['success_message']) ? $form->settings['success_message'] : $success_message;
            $redirect_url = isset($form->settings['redirect_url']) ? $form->settings['redirect_url'] : $redirect_url;
            $instant_redirect = isset($form->settings['instant_redirect']) ? $form->settings['instant_redirect'] : $instant_redirect;
            $email_from_address = isset($form->settings['email_from_address']) ? $form->settings['email_from_address'] : $email_from_address;
            $email_bcc = isset($form->settings['email_bcc']) ? $form->settings['email_bcc'] : $email_bcc;
            $fields = $form->fields;
        }
    }

    if (isset($_GET['updated'])) {
        $msg = ($_GET['updated'] == '1') ? 'Form created successfully!' : 'Form updated successfully!';
        echo '<div class="updated"><p>' . esc_html($msg) . '</p></div>';
    }

    ?>
    <div class="wrap">
        <h1><?php echo $is_new ? 'Add New Form' : 'Edit Form: ' . esc_html($form_name); ?></h1>

        <form method="post" action="" id="fqf-builder-form">
            <?php wp_nonce_field('fqf_form_nonce'); ?>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; max-width: 900px; margin-top: 20px;">
                <div class="card" style="padding: 20px; margin: 0;">
                    <h2>General Settings</h2>
                    <table class="form-table">
                        <tr>
                            <td><label>Form Name</label><br>
                                <input name="form_name" type="text" value="<?php echo esc_attr($form_name); ?>"
                                    class="widefat" required>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><input name="show_heading" type="checkbox" <?php checked($show_heading, 1); ?>> Show
                                    Form Heading</label><br>
                                <input name="heading_text" type="text" value="<?php echo esc_attr($heading_text); ?>"
                                    class="widefat" placeholder="Get a Fast Quote">
                            </td>
                        </tr>
                        <tr>
                            <td><label>Primary Color</label><br>
                                <input name="primary_color" type="text" value="<?php echo esc_attr($primary_color); ?>"
                                    class="fqf-color-picker">
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="card" style="padding: 20px; margin: 0;">
                    <h2>Notification Settings</h2>
                    <table class="form-table">
                        <tr>
                            <td><label>Receiver Email</label><br>
                                <input name="notification_email" type="email"
                                    value="<?php echo esc_attr($notification_email); ?>" class="widefat">
                            </td>
                        </tr>
                        <tr>
                            <td><label>Email From Name</label><br>
                                <input name="email_from" type="text" value="<?php echo esc_attr($email_from); ?>"
                                    class="widefat">
                            </td>
                        </tr>
                        <tr>
                            <td><label>Email From Address</label><br>
                                <input name="email_from_address" type="email"
                                    value="<?php echo esc_attr($email_from_address); ?>" class="widefat">
                            </td>
                        </tr>
                        <tr>
                            <td><label>BCC Email(s)</label><br>
                                <input name="email_bcc" type="text" value="<?php echo esc_attr($email_bcc); ?>"
                                    class="widefat" placeholder="email1@example.com, email2@example.com">
                                <p class="description">Separate multiple emails with commas.</p>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Email Subject</label><br>
                                <input name="email_subject" type="text" value="<?php echo esc_attr($email_subject); ?>"
                                    class="widefat">
                            </td>
                        </tr>
                    </table>
                </div>

                <div class="card" style="padding: 20px; margin: 0;">
                    <h2>Success Actions</h2>
                    <table class="form-table">
                        <tr>
                            <td><label>Thank You Message</label><br>
                                <textarea name="success_message" class="widefat"
                                    rows="3"><?php echo esc_textarea($success_message); ?></textarea>
                                <p class="description">Shown after successful submission.</p>
                            </td>
                        </tr>
                        <tr>
                            <td><label>Redirect URL (Optional)</label><br>
                                <input name="redirect_url" type="url" value="<?php echo esc_attr($redirect_url); ?>"
                                    class="widefat" placeholder="https://example.com/thanks">
                                <p class="description">Redirect user to this URL after submission.</p>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <label><input name="instant_redirect" type="checkbox" <?php checked($instant_redirect, 1); ?>> Instant Redirect</label>
                                <p class="description">Skip the success message and redirect immediately.</p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>

            <h2 style="margin-top: 30px;">Form Fields</h2>
            <div id="fqf-fields-container" style="max-width: 900px;">
                <?php foreach ($fields as $index => $field): ?>
                    <div class="fqf-field-row" data-index="<?php echo $index; ?>"
                        style="background:#fff; padding:15px; border:1px solid #ccd0d4; margin-bottom:15px; border-radius:4px; cursor: move; position: relative;">
                        <span class="dashicons dashicons-menu"
                            style="position: absolute; left: -25px; top: 15px; color: #ccc;"></span>

                        <div style="display:grid; grid-template-columns: 1.5fr 1fr 1fr 50px; gap:15px; align-items: end;">
                            <div>
                                <label><strong>Label</strong></label>
                                <input type="text" name="fields[<?php echo $index; ?>][label]"
                                    value="<?php echo esc_attr($field['label']); ?>" class="widefat">
                            </div>
                            <div>
                                <label><strong>Type</strong></label>
                                <select name="fields[<?php echo $index; ?>][type]" class="widefat fqf-type-selector">
                                    <option value="text" <?php selected($field['type'], 'text'); ?>>Text</option>
                                    <option value="email" <?php selected($field['type'], 'email'); ?>>Email</option>
                                    <option value="tel" <?php selected($field['type'], 'tel'); ?>>Phone</option>
                                    <option value="textarea" <?php selected($field['type'], 'textarea'); ?>>Textarea</option>
                                    <option value="select" <?php selected($field['type'], 'select'); ?>>Select</option>
                                </select>
                            </div>
                            <div>
                                <label><strong>Icon Style</strong></label>
                                <select name="fields[<?php echo $index; ?>][icon_type]" class="widefat fqf-icon-type-selector">
                                    <option value="fa" <?php selected($field['icon_type'], 'fa'); ?>>Font Awesome</option>
                                    <option value="svg" <?php selected($field['icon_type'], 'svg'); ?>>SVG Code / Paste</option>
                                    <option value="png" <?php selected($field['icon_type'], 'png'); ?>>Media Library / URL
                                    </option>
                                </select>
                            </div>
                            <div style="text-align: right;">
                                <button type="button" class="button button-link-delete fqf-remove-field"
                                    style="color: #a00;">&times;</button>
                            </div>
                        </div>

                        <div style="margin-top:15px; display:grid; grid-template-columns: 1.5fr 1fr 80px; gap:15px;">
                            <div class="fqf-icon-value-container">
                                <label><strong>Icon Content</strong></label>
                                <div class="fqf-icon-input-wrapper" style="display: flex; gap: 5px;">
                                    <textarea name="fields[<?php echo $index; ?>][icon_value]" class="widefat fqf-icon-value"
                                        rows="2"><?php echo esc_textarea($field['icon_value']); ?></textarea>
                                    <button type="button" class="button fqf-media-button"
                                        style="<?php echo ($field['icon_type'] !== 'png') ? 'display:none;' : ''; ?>">Media</button>
                                </div>
                            </div>
                            <div class="fqf-options-container"
                                style="<?php echo ($field['type'] !== 'select') ? 'display:none;' : ''; ?>">
                                <label><strong>Select Options</strong> (One per line)</label>
                                <textarea name="fields[<?php echo $index; ?>][options]" class="widefat"
                                    rows="2"><?php echo esc_textarea($field['options']); ?></textarea>
                            </div>
                            <div style="text-align: center;">
                                <label><strong>Required</strong></label><br>
                                <input type="checkbox" name="fields[<?php echo $index; ?>][required]" <?php checked($field['required'], 1); ?>>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

            <div style="margin-top: 20px; max-width: 900px;">
                <button type="button" id="fqf-add-field" class="button button-large">Add Field</button>
                <input type="submit" name="fqf_save_form" class="button button-primary button-large" value="Save Form"
                    style="float: right;">
            </div>
        </form>
    </div>

    <script>
        jQuery(document).ready(function ($) {
            $('.fqf-color-picker').wpColorPicker();

            $("#fqf-fields-container").sortable({
                placeholder: "ui-state-highlight",
                update: function () { reindexFields(); }
            });

            const defaultIcons = {
                'text': 'fas fa-font',
                'email': 'fas fa-envelope',
                'tel': 'fas fa-phone',
                'textarea': 'fas fa-align-left',
                'select': 'fas fa-list'
            };

            function reindexFields() {
                $('#fqf-fields-container .fqf-field-row').each(function (index) {
                    $(this).find('input, select, textarea').each(function () {
                        var name = $(this).attr('name');
                        if (name) $(this).attr('name', name.replace(/fields\[\d+\]/, 'fields[' + index + ']'));
                    });
                });
            }

            $('#fqf-add-field').click(function () {
                var index = $('#fqf-fields-container .fqf-field-row').length;
                var html = `<div class="fqf-field-row" style="background:#fff; padding:15px; border:1px solid #ccd0d4; margin-bottom:15px; border-radius:4px; cursor: move; position: relative;">
                <span class="dashicons dashicons-menu" style="position: absolute; left: -25px; top: 15px; color: #ccc;"></span>
                <div style="display:grid; grid-template-columns: 1.5fr 1fr 1fr 50px; gap:15px; align-items: end;">
                    <div><label><strong>Label</strong></label><input type="text" name="fields[${index}][label]" class="widefat"></div>
                    <div><label><strong>Type</strong></label><select name="fields[${index}][type]" class="widefat fqf-type-selector">
                        <option value="text">Text</option><option value="email">Email</option><option value="tel">Phone</option><option value="textarea">Textarea</option><option value="select">Select</option>
                    </select></div>
                    <div><label><strong>Icon Style</strong></label><select name="fields[${index}][icon_type]" class="widefat fqf-icon-type-selector">
                        <option value="fa">Font Awesome</option><option value="svg">SVG Code / Paste</option><option value="png">Media Library / URL</option>
                    </select></div>
                    <div style="text-align: right;"><button type="button" class="button button-link-delete fqf-remove-field" style="color: #a00;">&times;</button></div>
                </div>
                <div style="margin-top:15px; display:grid; grid-template-columns: 1.5fr 1fr 80px; gap:15px;">
                    <div class="fqf-icon-value-container">
                        <label><strong>Icon Content</str ong></label>
                        <div style="display: flex; gap: 5px;">
                       <textarea name="fields[${index}][icon_valu e]" class="widefat fqf-icon-value" rows="2">fas fa-font</textarea>
                       <button type="button" class="button fqf-media-button" style="display:none;">Media</button>
                        </div>
                    </div>
                    <div class="fqf-options-container" style="display:none;"><label><strong>Select Options</strong></label><textarea name="fields[${index}][options]" class="widefat" rows="2"></textarea></div>
                    <div style="text-align: center;"><label><strong>Required</strong></label><br><input type="checkbox" name="fields[${index}][required]"></div>
                </div>
            </div>`;
                $('#fqf-fields-container').append(html);
            });

            $(document).on('click', '.fqf-remove-field', function () {
                if (confirm('Remove field?')) { $(this).closest('.fqf-field-row').remove(); reindexFields(); }
            });

            $(document).on('change', '.fqf-type-selector', function () {
                var row = $(this).closest('.fqf-field-row');
                var type = $(this).val();
                row.find('.fqf-options-container').toggle(type === 'select');

                if (row.find('.fqf-icon-type-selector').val() === 'fa') {
                    row.find('.fqf-icon-value').val(defaultIcons[type]);
                }
            });

            $(document).on('change', '.fqf-icon-type-selector', function () {
                var row = $(this).closest('.fqf-field-row');
                var iconType = $(this).val();
                row.find('.fqf-media-button').toggle(iconType === 'png');

                if (iconType === 'fa') {
                    var fieldType = row.find('.fqf-type-selector').val();
                    row.find('.fqf-icon-value').val(defaultIcons[fieldType]);
                }
            });

            $(document).on('click', '.fqf-media-button', function (e) {
                e.preventDefault();
                var button = $(this);
                var target = button.prev('.fqf-icon-value');
                var custom_uploader = wp.media({
                    title: 'Select Icon',
                    button: { text: 'Use this icon' },
                    multiple: false
                }).on('select', function () {
                    var attachment = custom_uploader.state().get('selection').first().toJSON();
                    target.val(attachment.url);
                }).open();
            });
        });
    </script>
    <style>
        .ui-state-highlight {
            height: 100px;
            background: #f0f0f1;
            border: 1px dashed #ccc;
            margin-bottom: 15px;
        }

        .fqf-field-row:hover {
            border-color: #6366F1;
        }
    </style>
    <?php
}
