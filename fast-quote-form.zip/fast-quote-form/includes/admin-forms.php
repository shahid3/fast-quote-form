<?php
if (!defined('ABSPATH')) {
    exit;
}

function fqf_render_forms_page()
{
    global $wpdb;
    $table_name = $wpdb->prefix . 'fqf_forms';

    // Handle Deletion
    if (isset($_GET['action']) && $_GET['action'] === 'delete' && isset($_GET['id'])) {
        check_admin_referer('fqf_delete_form_' . $_GET['id']);
        $wpdb->delete($table_name, ['id' => intval($_GET['id'])]);
        echo '<div class="updated"><p>Form deleted.</p></div>';
    }


    $forms = FQF_DB_Manager::get_all_forms();
    ?>
    <div class="wrap">
        <h1 class="wp-heading-inline">Fast Quotes Forms</h1>
        <a href="<?php echo admin_url('admin.php?page=fast-quote-settings'); ?>" class="page-title-action">Add New</a>
        <hr class="wp-header-end">

        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Form Name</th>
                    <th>Shortcode</th>
                    <th>Submissions</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($forms): ?>
                    <?php foreach ($forms as $form):
                        $entries_count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}fast_quotes WHERE form_id = %d", $form->id));
                        ?>
                        <tr>
                            <td><strong><a href="<?php echo admin_url('admin.php?page=fast-quote-settings&id=' . $form->id); ?>">
                                        <?php echo esc_html($form->name); ?>
                                    </a></strong></td>
                            <td><code>[fast_quote_form id="<?php echo $form->id; ?>"]</code></td>
                            <td><a href="<?php echo admin_url('admin.php?page=fast-quote-entries&form_id=' . $form->id); ?>">
                                    <?php echo $entries_count; ?>
                                </a></td>
                            <td>
                                <?php echo esc_html($form->created_at); ?>
                            </td>
                            <td>
                                <a href="<?php echo admin_url('admin.php?page=fast-quote-settings&id=' . $form->id); ?>">Edit</a> |
                                <a href="<?php echo wp_nonce_url(admin_url('admin.php?page=fast-quote-forms&action=delete&id=' . $form->id), 'fqf_delete_form_' . $form->id); ?>"
                                    style="color:red;" onclick="return confirm('Delete this form?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">No forms found. <a
                                href="<?php echo admin_url('admin.php?page=fast-quote-settings'); ?>">Create your first
                                form</a>.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php
}
