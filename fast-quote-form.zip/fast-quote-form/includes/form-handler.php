<?php
if (!defined('ABSPATH')) {
    exit;
}

add_action('wp_ajax_fqf_submit_quote', 'fqf_handle_quote_submission');
add_action('wp_ajax_nopriv_fqf_submit_quote', 'fqf_handle_quote_submission');

function fqf_handle_quote_submission()
{
    check_ajax_referer('fqf_quote_nonce', 'nonce');

    $form_id = isset($_POST['form_id']) ? intval($_POST['form_id']) : 0;
    $form = FQF_DB_Manager::get_form($form_id);

    if (!$form) {
        wp_send_json_error('Form configuration not found.');
    }

    $submission_data = [];
    $fields = $form->fields;

    foreach ($fields as $field) {
        $field_id = sanitize_title($field['label']);
        if (isset($_POST[$field_id])) {
            if ($field['type'] === 'textarea')
                $submission_data[$field['label']] = sanitize_textarea_field($_POST[$field_id]);
            elseif ($field['type'] === 'email')
                $submission_data[$field['label']] = sanitize_email($_POST[$field_id]);
            else
                $submission_data[$field['label']] = sanitize_text_field($_POST[$field_id]);
        }
    }

    if (empty($submission_data)) {
        wp_send_json_error('No valid data received.');
    }

    $saved = FQF_DB_Manager::save_entry($form_id, $submission_data);

    if ($saved) {
        $notification_email = isset($form->settings['notification_email']) ? $form->settings['notification_email'] : get_option('admin_email');
        $from_name = isset($form->settings['email_from']) ? $form->settings['email_from'] : get_bloginfo('name');
        $from_email = isset($form->settings['email_from_address']) ? $form->settings['email_from_address'] : get_option('admin_email');
        $bcc_emails = isset($form->settings['email_bcc']) ? $form->settings['email_bcc'] : '';
        $subject = isset($form->settings['email_subject']) ? $form->settings['email_subject'] : 'New Quote Request: ' . $form->name;

        // Find customer email for Reply-To
        $customer_email = '';
        foreach ($fields as $field) {
            if ($field['type'] === 'email') {
                $field_id = sanitize_title($field['label']);
                if (isset($_POST[$field_id])) {
                    $customer_email = sanitize_email($_POST[$field_id]);
                    break;
                }
            }
        }

        $headers = [
            'Content-Type: text/plain; charset=UTF-8',
            'From: ' . $from_name . ' <' . $from_email . '>'
        ];

        if (!empty($customer_email)) {
            $headers[] = 'Reply-To: <' . $customer_email . '>';
        }

        if (!empty($bcc_emails)) {
            $headers[] = 'Bcc: ' . $bcc_emails;
        }

        $message = "New quote request for: " . $form->name . "\n\n";
        foreach ($submission_data as $label => $value) {
            $message .= "$label: $value\n";
        }

        wp_mail($notification_email, $subject, $message, $headers);

        // Send success details back to JS
        wp_send_json_success([
            'message' => isset($form->settings['success_message']) ? $form->settings['success_message'] : 'Your quote request has been sent successfully!',
            'redirect' => isset($form->settings['redirect_url']) ? $form->settings['redirect_url'] : '',
            'instant_redirect' => isset($form->settings['instant_redirect']) ? $form->settings['instant_redirect'] : 0
        ]);
    } else {
        wp_send_json_error('Failed to save request.');
    }
}
