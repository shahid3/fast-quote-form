<?php
if (!defined('ABSPATH')) {
    exit;
}

function fqf_render_quote_form($atts)
{
    $atts = shortcode_atts(['id' => 0], $atts);
    $form_id = intval($atts['id']);

    if ($form_id === 0) {
        // Try to get the latest form if no ID is provided
        global $wpdb;
        $form_id = $wpdb->get_var("SELECT id FROM {$wpdb->prefix}fqf_forms ORDER BY id DESC LIMIT 1");
    }

    if (!$form_id) {
        return '<p>No form found. Please create one in the Form Builder.</p>';
    }

    $form = FQF_DB_Manager::get_form($form_id);
    if (!$form) {
        return '<p>Form not found.</p>';
    }

    $fields = $form->fields;
    $primary_color = isset($form->settings['primary_color']) ? $form->settings['primary_color'] : '#6366F1';

    // Unique ID for this form instance
    $form_instance_id = 'fqf-form-' . $form_id;

    ob_start();
    ?>
    <style>
        #<?php echo $form_instance_id; ?> .fqf-input-group input:focus,
        #<?php echo $form_instance_id; ?> .fqf-input-group select:focus,
        #<?php echo $form_instance_id; ?> .fqf-input-group textarea:focus {
            border-bottom-color:
                <?php echo $primary_color; ?>
                !important;
            background:
                <?php echo $primary_color; ?>
                05 !important;
        }

        #<?php echo $form_instance_id; ?> .fqf-submit-btn {
            background:
                <?php echo $primary_color; ?>
                !important;
            box-shadow: 0 10px 30px
                <?php echo $primary_color; ?>
                4d !important;
        }

        #<?php echo $form_instance_id; ?> .fqf-submit-btn:hover {
            box-shadow: 0 15px 40px
                <?php echo $primary_color; ?>
                66 !important;
        }

        #<?php echo $form_instance_id; ?> .fqf-privacy-link {
            color:
                <?php echo $primary_color; ?>
            ;
        }
    </style>

    <div class="fqf-container" id="<?php echo $form_instance_id; ?>">
        <div class="fqf-form-card">
            <?php if (isset($form->settings['show_heading']) && $form->settings['show_heading']): ?>
                <h2><?php echo esc_html(isset($form->settings['heading_text']) ? $form->settings['heading_text'] : 'Get a Fast Quote'); ?>
                </h2>
            <?php endif; ?>

            <form class="fqf-quote-form-js">
                <input type="hidden" name="form_id" value="<?php echo $form_id; ?>">

                <?php foreach ($fields as $field):
                    $field_id = sanitize_title($field['label']);
                    $required = !empty($field['required']) ? 'required' : '';
                    ?>
                    <div class="fqf-input-group">
                        <div class="fqf-input-icon">
                            <?php
                            if ($field['icon_type'] === 'fa') {
                                echo '<i class="' . esc_attr($field['icon_value']) . '"></i>';
                            } elseif ($field['icon_type'] === 'svg') {
                                echo $field['icon_value'];
                            } elseif ($field['icon_type'] === 'png') {
                                echo '<img src="' . esc_url($field['icon_value']) . '" alt="" style="width:20px; height:20px; object-fit: contain;">';
                            }
                            ?>
                        </div>

                        <?php if ($field['type'] === 'textarea'): ?>
                            <textarea name="<?php echo esc_attr($field_id); ?>"
                                placeholder="<?php echo esc_attr($field['label']) . (!empty($required) ? ' *' : ''); ?>" <?php echo $required; ?> rows="4"></textarea>
                        <?php elseif ($field['type'] === 'select'):
                            $options = explode("\n", $field['options']);
                            ?>
                            <select name="<?php echo esc_attr($field_id); ?>" <?php echo $required; ?>>
                                <option value=""><?php echo esc_html($field['label']); ?></option>
                                <?php foreach ($options as $option):
                                    $option = trim($option);
                                    if (empty($option))
                                        continue;
                                    ?>
                                    <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input type="<?php echo esc_attr($field['type']); ?>" name="<?php echo esc_attr($field_id); ?>"
                                placeholder="<?php echo esc_attr($field['label']) . (!empty($required) ? ' *' : ''); ?>" <?php echo $required; ?>>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <button type="submit" class="fqf-submit-btn">
                    Submit
                </button>

                <div class="fqf-message"></div>
            </form>

            <div class="fqf-arrow-decoration">
                <svg version="1.0" xmlns="http://www.w3.org/2000/svg" width="60" height="80" viewBox="0 0 60 80"
                    preserveAspectRatio="xMidYMid meet" style="fill: <?php echo $primary_color; ?>;">
                    <g transform="translate(0.000000,80.000000) scale(0.100000,-0.100000)" stroke="none">
                        <path
                            d="M8 785 c-17 -17 47 -234 102 -342 63 -126 214 -291 317 -345 24 -13 43 -26 43 -30 0 -5 -17 -8 -37 -9 -57 -1 -87 -13 -91 -33 -4 -16 2 -18 55 -12 32 3 88 8 125 12 56 5 68 9 68 24 0 28 -93 159 -112 160 -23 0 -23 -17 2 -58 11 -18 20 -35 20 -37 0 -3 -24 6 -52 21 -66 33 -220 187 -270 270 -46 74 -90 187 -113 284 -10 41 -19 81 -21 88 -3 12 -26 17 -36 7z" />
                    </g>
                </svg>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('fast_quote_form', 'fqf_render_quote_form');
