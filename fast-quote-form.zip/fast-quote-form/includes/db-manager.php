<?php
if (!defined('ABSPATH')) {
    exit;
}

class FQF_DB_Manager
{
    public static function create_table()
    {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Forms Table
        $forms_table = $wpdb->prefix . 'fqf_forms';
        $sql_forms = "CREATE TABLE $forms_table (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  name varchar(100) NOT NULL,
  fields longtext NOT NULL,
  settings longtext NOT NULL,
  created_at datetime NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

        // Entries Table
        $entries_table = $wpdb->prefix . 'fast_quotes';
        $sql_entries = "CREATE TABLE $entries_table (
  id mediumint(9) NOT NULL AUTO_INCREMENT,
  form_id mediumint(9) NOT NULL,
  time datetime NOT NULL,
  data longtext NOT NULL,
  status varchar(20) DEFAULT 'active' NOT NULL,
  PRIMARY KEY  (id)
) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_forms);
        dbDelta($sql_entries);

        // Create a default form if none exists
        if ($wpdb->get_var("SELECT COUNT(*) FROM $forms_table") == 0) {
            $default_fields = [
                ['label' => 'Name', 'type' => 'text', 'icon_type' => 'fa', 'icon_value' => 'fas fa-user', 'required' => 1, 'options' => ''],
                ['label' => 'Email', 'type' => 'email', 'icon_type' => 'fa', 'icon_value' => 'fas fa-envelope', 'required' => 1, 'options' => '']
            ];
            $default_settings = [
                'show_heading' => 1,
                'heading_text' => 'Get a Fast Quote',
                'primary_color' => '#6366F1',
                'notification_email' => get_option('admin_email'),
                'email_subject' => 'New Quote Request',
                'email_from' => get_bloginfo('name'),
                'success_message' => 'Your quote request has been sent successfully!',
                'redirect_url' => '',
                'instant_redirect' => 0
            ];

            $wpdb->insert($forms_table, [
                'name' => 'Default Form',
                'fields' => json_encode($default_fields),
                'settings' => json_encode($default_settings),
                'created_at' => current_time('mysql')
            ]);
        }
    }

    public static function save_entry($form_id, $data)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fast_quotes';

        return $wpdb->insert($table_name, [
            'form_id' => $form_id,
            'time' => current_time('mysql'),
            'data' => json_encode($data),
        ]);
    }

    public static function get_form($id)
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fqf_forms';
        $form = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id));
        if ($form) {
            $form->fields = json_decode($form->fields, true);
            $form->settings = json_decode($form->settings, true);
        }
        return $form;
    }

    public static function get_all_forms()
    {
        global $wpdb;
        $table_name = $wpdb->prefix . 'fqf_forms';
        return $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
    }
}
