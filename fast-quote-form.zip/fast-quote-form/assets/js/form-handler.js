jQuery(document).ready(function ($) {
    $(document).on('submit', '.fqf-quote-form-js', function (e) {
        e.preventDefault();

        var $form = $(this);
        var $btn = $form.find('.fqf-submit-btn');
        var $msg = $form.find('.fqf-message');

        $btn.prop('disabled', true).text('Sending...');
        $msg.removeClass('success error').hide();

        var formData = $form.serialize();
        formData += '&action=fqf_submit_quote&nonce=' + fqf_ajax.nonce;

        $.ajax({
            url: fqf_ajax.ajax_url,
            type: 'POST',
            data: formData,
            success: function (response) {
                if (response.success) {
                    var data = response.data;

                    // Handle redirection if URL is provided AND instant_redirect is checked
                    if (data.redirect && data.instant_redirect) {
                        window.location.href = data.redirect;
                    } else {
                        // Show success message if not redirecting instantly
                        $msg.addClass('success').text(data.message).show();
                    }

                    $form[0].reset();
                } else {
                    $msg.addClass('error').text(response.data).show();
                }
            },
            error: function () {
                $msg.addClass('error').text('Something went wrong.').show();
            },
            complete: function () {
                $btn.prop('disabled', false).text('Submit');
            }
        });
    });
});
